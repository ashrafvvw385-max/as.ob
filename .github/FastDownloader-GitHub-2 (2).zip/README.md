# FastDownloader

Self-hosted Android download client using Kotlin/Jetpack Compose on Android and
aria2 + FastAPI + Nginx on a VPS.

## Repository layout

- `app/` — Android application
- `server/` — VPS Docker Compose stack
- `.github/workflows/android.yml` — automatic debug APK build

## GitHub Actions

Push the repository to `main` and the workflow builds:
`app/build/outputs/apk/debug/app-debug.apk`

The APK is published as a GitHub Actions artifact named `FastDownloader-debug`.

## VPS

Copy `.env.example` to `.env`, set strong secrets, then run:

    docker compose up -d

The Android app can then connect to the VPS base address.

## Important

Use HTTPS in production. The API token protects API endpoints, while download
files should also be protected appropriately if the server is exposed publicly.

Only use direct download URLs and files you are authorized to download.
This project does not bypass DRM, paywalls, authentication, or access controls.
